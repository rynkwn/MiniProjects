public class Tester
{
	public static void main(String [] args) throws Exception
	{
		GUI test = new GUI(); 
	}
}